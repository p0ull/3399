var dir_75d5c689b70aefa142bdf5ebcb7d98a3 =
[
    [ "assets", "dir_9127a1cb36a7caf66e62b387863738ab.html", "dir_9127a1cb36a7caf66e62b387863738ab" ],
    [ "hello_world_opencl.cpp", "hello__world__opencl_8cpp.html", "hello__world__opencl_8cpp" ]
];