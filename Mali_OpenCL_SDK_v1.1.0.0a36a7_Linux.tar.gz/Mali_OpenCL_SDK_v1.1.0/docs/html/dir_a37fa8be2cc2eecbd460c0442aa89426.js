var dir_a37fa8be2cc2eecbd460c0442aa89426 =
[
    [ "sobel.cl", "sobel_8cl.html", "sobel_8cl" ]
];