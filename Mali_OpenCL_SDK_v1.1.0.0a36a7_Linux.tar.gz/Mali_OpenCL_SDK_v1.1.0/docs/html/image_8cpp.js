var image_8cpp =
[
    [ "loadFromBitmap", "image_8cpp.html#a24ebc43a2f3d72aff84912a1a69f2c39", null ],
    [ "luminanceToRGB", "image_8cpp.html#a9390e4ddc634d83452a15e93017ab979", null ],
    [ "RGBAToRGB", "image_8cpp.html#a872cec0732df69b80796a61acea716f0", null ],
    [ "RGBToLuminance", "image_8cpp.html#a75fa143dccc45f3d5dc030884ca09cc9", null ],
    [ "RGBToRGBA", "image_8cpp.html#a83b7aea3d44c26db2222227c0dc5d19a", null ],
    [ "saveToBitmap", "image_8cpp.html#ad7fed8ed5795a8ddd3e86265cc5a4d31", null ]
];