var structbitmap_header =
[
    [ "creator1", "structbitmap_header.html#ad1281577a12cb4314cfe869877135231", null ],
    [ "creator2", "structbitmap_header.html#aafdafe00204ad8448ab9cd98aa3040b2", null ],
    [ "fileSize", "structbitmap_header.html#ad06f4dbac80aa4d85163d3862ed34197", null ],
    [ "offset", "structbitmap_header.html#a5e74a0bfe6340ad581369b48bce59dbe", null ]
];