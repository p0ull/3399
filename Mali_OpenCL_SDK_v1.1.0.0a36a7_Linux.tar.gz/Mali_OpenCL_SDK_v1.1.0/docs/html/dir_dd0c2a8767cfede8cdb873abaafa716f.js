var dir_dd0c2a8767cfede8cdb873abaafa716f =
[
    [ "assets", "dir_a37fa8be2cc2eecbd460c0442aa89426.html", "dir_a37fa8be2cc2eecbd460c0442aa89426" ],
    [ "sobel.cpp", "sobel_8cpp.html", "sobel_8cpp" ]
];