var image_8h =
[
    [ "bitmapMagic", "structbitmap_magic.html", "structbitmap_magic" ],
    [ "bitmapHeader", "structbitmap_header.html", "structbitmap_header" ],
    [ "bitmapInformationHeader", "structbitmap_information_header.html", "structbitmap_information_header" ],
    [ "loadFromBitmap", "image_8h.html#ae8afb226cfa212cce225a77a0ff79121", null ],
    [ "luminanceToRGB", "image_8h.html#a9390e4ddc634d83452a15e93017ab979", null ],
    [ "RGBAToRGB", "image_8h.html#a3d566da55411efac7e49e2f33bf6c155", null ],
    [ "RGBToLuminance", "image_8h.html#a95b53cb5341aa2660b74a5f3a40228de", null ],
    [ "RGBToRGBA", "image_8h.html#a189e940abcfb40459918c86ab01a1121", null ],
    [ "saveToBitmap", "image_8h.html#ab9744225ef92254ada77ddaeaddad25d", null ]
];