var common_8h =
[
    [ "checkSuccess", "common_8h.html#a73727ed6f5d821d8c97756404e145644", null ],
    [ "cleanUpOpenCL", "common_8h.html#acd459e74d0cef3c4616c7ce1a5a47f4d", null ],
    [ "createCommandQueue", "common_8h.html#a30ee399cc6a4b82d46c581f037b447fa", null ],
    [ "createContext", "common_8h.html#a6fc67d121370b02ac8bff71ec00a7665", null ],
    [ "createProgram", "common_8h.html#a7fe72dc9fb4aad614e19d6bfbb2a7fce", null ],
    [ "errorNumberToString", "common_8h.html#a8ce6fa1f13405092e05b3a1b464b1f77", null ],
    [ "imageChannelDataTypeToString", "common_8h.html#a1200474d0c84aaaf23b5bf36b4d9abfd", null ],
    [ "imageChannelOrderToString", "common_8h.html#abf4221def5272b7188679785d807f6cb", null ],
    [ "isExtensionSupported", "common_8h.html#a4b392a835c01476e368c4444bfef3017", null ],
    [ "printProfilingInfo", "common_8h.html#a33ff0013574626bb47147495e02b5d08", null ],
    [ "printSupported2DImageFormats", "common_8h.html#a736045ae74d9ed8d35cacce59b92772a", null ]
];