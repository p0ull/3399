var mandelbrot_8cl =
[
    [ "MAX_ITER", "mandelbrot_8cl.html#acd517c6f195c75b9dd0f3aad65326f3b", null ],
    [ "createStartX", "mandelbrot_8cl.html#a4dffa8ed5ea4612c75f705e514351c4a", null ],
    [ "mandelbrot", "mandelbrot_8cl.html#aa9c49529b3f34c7675aedea1b068ef9a", null ]
];