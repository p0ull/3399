var sobel_8cl =
[
    [ "sobel", "sobel_8cl.html#ad999d1681236d38b8c3e05c610a99850", null ]
];