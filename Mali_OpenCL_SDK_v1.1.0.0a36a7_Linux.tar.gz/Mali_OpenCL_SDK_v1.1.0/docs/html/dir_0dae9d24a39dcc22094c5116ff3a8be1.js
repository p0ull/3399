var dir_0dae9d24a39dcc22094c5116ff3a8be1 =
[
    [ "image_scaling.cl", "image__scaling_8cl.html", "image__scaling_8cl" ]
];