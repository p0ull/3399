var searchData=
[
  ['magic',['magic',['../structbitmap_magic.html#a477646205ecad5019613626f0b478694',1,'bitmapMagic']]],
  ['main',['main',['../64__bit__integer_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;64_bit_integer.cpp'],['../fir__float_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;fir_float.cpp'],['../hello__world__c_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;hello_world_c.cpp'],['../hello__world__opencl_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;hello_world_opencl.cpp'],['../hello__world__vector_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;hello_world_vector.cpp'],['../image__scaling_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;image_scaling.cpp'],['../mandelbrot_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;mandelbrot.cpp'],['../sgemm_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;sgemm.cpp'],['../sobel_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;sobel.cpp'],['../sobel__no__vectors_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;sobel_no_vectors.cpp'],['../template_8cpp.html#a840291bc02cba5474a4cb46a9b9566fe',1,'main(void):&#160;template.cpp']]],
  ['main_5fpage_2edox',['main_page.dox',['../main__page_8dox.html',1,'']]],
  ['mandelbrot',['mandelbrot',['../mandelbrot_8cl.html#aa9c49529b3f34c7675aedea1b068ef9a',1,'mandelbrot.cl']]],
  ['mandelbrot_2ecl',['mandelbrot.cl',['../mandelbrot_8cl.html',1,'']]],
  ['mandelbrot_2ecpp',['mandelbrot.cpp',['../mandelbrot_8cpp.html',1,'']]],
  ['mandelbrot_2edox',['mandelbrot.dox',['../mandelbrot_8dox.html',1,'']]],
  ['mandelbrot',['Mandelbrot',['../mandelbrot_tutorial.html',1,'tutorials']]],
  ['max_5fiter',['MAX_ITER',['../mandelbrot_8cl.html#acd517c6f195c75b9dd0f3aad65326f3b',1,'mandelbrot.cl']]],
  ['memory_5fbuffers_2edox',['memory_buffers.dox',['../memory__buffers_8dox.html',1,'']]],
  ['memory_20buffers',['Memory Buffers',['../memory_buffers_tutorial.html',1,'tutorials']]]
];
