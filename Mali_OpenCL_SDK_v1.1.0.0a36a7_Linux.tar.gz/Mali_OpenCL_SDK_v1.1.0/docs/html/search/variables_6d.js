var searchData=
[
  ['magic',['magic',['../structbitmap_magic.html#a477646205ecad5019613626f0b478694',1,'bitmapMagic']]]
];
