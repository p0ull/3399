var searchData=
[
  ['fir_20filter',['FIR Filter',['../fir_tutorial.html',1,'tutorials']]],
  ['from_20c_20to_20opencl',['From C to OpenCL',['../hello_world_open_c_l_tutorial.html',1,'helloWorldTutorial']]]
];
