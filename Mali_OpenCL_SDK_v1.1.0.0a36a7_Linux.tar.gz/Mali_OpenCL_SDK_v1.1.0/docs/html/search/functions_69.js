var searchData=
[
  ['image_5fscaling',['image_scaling',['../image__scaling_8cl.html#a2f2c7656161bcd4a3956c362d0052b26',1,'image_scaling.cl']]],
  ['imagechanneldatatypetostring',['imageChannelDataTypeToString',['../common_8cpp.html#af351b63fc0df43f3702d01de76d344ae',1,'imageChannelDataTypeToString(cl_channel_type channelDataType):&#160;common.cpp'],['../common_8h.html#a1200474d0c84aaaf23b5bf36b4d9abfd',1,'imageChannelDataTypeToString(cl_channel_type channelDataType):&#160;common.cpp']]],
  ['imagechannelordertostring',['imageChannelOrderToString',['../common_8cpp.html#afbc9c225ddee8ca4913817d1d9f55307',1,'imageChannelOrderToString(cl_channel_order channelOrder):&#160;common.cpp'],['../common_8h.html#abf4221def5272b7188679785d807f6cb',1,'imageChannelOrderToString(cl_channel_order channelOrder):&#160;common.cpp']]],
  ['isextensionsupported',['isExtensionSupported',['../common_8cpp.html#ad800ae2b2358904a9051a31f76e711c3',1,'isExtensionSupported(cl_device_id device, string extension):&#160;common.cpp'],['../common_8h.html#a4b392a835c01476e368c4444bfef3017',1,'isExtensionSupported(cl_device_id device, std::string extension):&#160;common.h']]]
];
