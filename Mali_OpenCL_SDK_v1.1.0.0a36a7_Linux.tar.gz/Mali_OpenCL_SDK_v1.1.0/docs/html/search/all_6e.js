var searchData=
[
  ['numberofcolorplanes',['numberOfColorPlanes',['../structbitmap_information_header.html#a92ce2fb0499b65ccb0dccbec12b44c4c',1,'bitmapInformationHeader']]],
  ['numberofcolors',['numberOfColors',['../structbitmap_information_header.html#ab8a3e77e6b66d1361d65523a99104f5f',1,'bitmapInformationHeader']]],
  ['numberofimportantcolors',['numberOfImportantColors',['../structbitmap_information_header.html#aa6296b037bae6831a6c53f6115c29769',1,'bitmapInformationHeader']]]
];
