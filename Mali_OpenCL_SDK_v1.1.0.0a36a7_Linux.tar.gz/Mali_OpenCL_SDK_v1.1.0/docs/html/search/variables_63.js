var searchData=
[
  ['compressiontype',['compressionType',['../structbitmap_information_header.html#a1a6659ee7987cc1be662ec93a6f2eef7',1,'bitmapInformationHeader']]],
  ['creator1',['creator1',['../structbitmap_header.html#ad1281577a12cb4314cfe869877135231',1,'bitmapHeader']]],
  ['creator2',['creator2',['../structbitmap_header.html#aafdafe00204ad8448ab9cd98aa3040b2',1,'bitmapHeader']]]
];
