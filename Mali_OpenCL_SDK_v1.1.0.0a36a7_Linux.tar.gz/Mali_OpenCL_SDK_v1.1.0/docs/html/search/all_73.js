var searchData=
[
  ['sampler',['sampler',['../image__scaling_8cl.html#a9165c6046146d2d28cc268394d585f17',1,'image_scaling.cl']]],
  ['savetobitmap',['saveToBitmap',['../image_8cpp.html#ad7fed8ed5795a8ddd3e86265cc5a4d31',1,'saveToBitmap(string filename, int width, int height, const unsigned char *imageData):&#160;image.cpp'],['../image_8h.html#ab9744225ef92254ada77ddaeaddad25d',1,'saveToBitmap(std::string filename, int width, int height, const unsigned char *imageData):&#160;image.h']]],
  ['sgemm',['sgemm',['../sgemm_8cl.html#abfe7be25d42e6bb53f76001bdbab6b25',1,'sgemm.cl']]],
  ['sgemm_2ecl',['sgemm.cl',['../sgemm_8cl.html',1,'']]],
  ['sgemm_2ecpp',['sgemm.cpp',['../sgemm_8cpp.html',1,'']]],
  ['sgemm_2edox',['sgemm.dox',['../sgemm_8dox.html',1,'']]],
  ['sgemminitialize',['sgemmInitialize',['../sgemm_8cpp.html#ad08e4e7aca2ad6900f5f5c84d88b6aff',1,'sgemm.cpp']]],
  ['sgemm',['SGEMM',['../sgemm_tutorial.html',1,'tutorials']]],
  ['size',['size',['../structbitmap_information_header.html#afd30cb5246210713920211afb56f13f0',1,'bitmapInformationHeader']]],
  ['sobel',['sobel',['../sobel_8cl.html#ad999d1681236d38b8c3e05c610a99850',1,'sobel.cl']]],
  ['sobel_2ecl',['sobel.cl',['../sobel_8cl.html',1,'']]],
  ['sobel_2ecpp',['sobel.cpp',['../sobel_8cpp.html',1,'']]],
  ['sobel_2edox',['sobel.dox',['../sobel_8dox.html',1,'']]],
  ['sobel_5fno_5fvectors',['sobel_no_vectors',['../sobel__no__vectors_8cl.html#aba83b870a7ef709e9a5608496084ec3a',1,'sobel_no_vectors.cl']]],
  ['sobel_5fno_5fvectors_2ecl',['sobel_no_vectors.cl',['../sobel__no__vectors_8cl.html',1,'']]],
  ['sobel_5fno_5fvectors_2ecpp',['sobel_no_vectors.cpp',['../sobel__no__vectors_8cpp.html',1,'']]],
  ['sobel_20filter',['Sobel Filter',['../sobel_tutorial.html',1,'tutorials']]],
  ['support',['Support',['../support.html',1,'']]],
  ['support_2edox',['support.dox',['../support_8dox.html',1,'']]]
];
