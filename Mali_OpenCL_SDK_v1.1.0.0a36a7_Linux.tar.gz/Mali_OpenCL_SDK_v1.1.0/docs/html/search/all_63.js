var searchData=
[
  ['checksuccess',['checkSuccess',['../common_8cpp.html#a73727ed6f5d821d8c97756404e145644',1,'checkSuccess(cl_int errorNumber):&#160;common.cpp'],['../common_8h.html#a73727ed6f5d821d8c97756404e145644',1,'checkSuccess(cl_int errorNumber):&#160;common.cpp']]],
  ['cleanupopencl',['cleanUpOpenCL',['../common_8cpp.html#acd459e74d0cef3c4616c7ce1a5a47f4d',1,'cleanUpOpenCL(cl_context context, cl_command_queue commandQueue, cl_program program, cl_kernel kernel, cl_mem *memoryObjects, int numberOfMemoryObjects):&#160;common.cpp'],['../common_8h.html#acd459e74d0cef3c4616c7ce1a5a47f4d',1,'cleanUpOpenCL(cl_context context, cl_command_queue commandQueue, cl_program program, cl_kernel kernel, cl_mem *memoryObjects, int numberOfMemoryObjects):&#160;common.cpp']]],
  ['common_2ecpp',['common.cpp',['../common_8cpp.html',1,'']]],
  ['common_2eh',['common.h',['../common_8h.html',1,'']]],
  ['common_5ferrors_2edox',['common_errors.dox',['../common__errors_8dox.html',1,'']]],
  ['common_20issues',['Common Issues',['../common_issues.html',1,'']]],
  ['compressiontype',['compressionType',['../structbitmap_information_header.html#a1a6659ee7987cc1be662ec93a6f2eef7',1,'bitmapInformationHeader']]],
  ['createcommandqueue',['createCommandQueue',['../common_8cpp.html#a30ee399cc6a4b82d46c581f037b447fa',1,'createCommandQueue(cl_context context, cl_command_queue *commandQueue, cl_device_id *device):&#160;common.cpp'],['../common_8h.html#a30ee399cc6a4b82d46c581f037b447fa',1,'createCommandQueue(cl_context context, cl_command_queue *commandQueue, cl_device_id *device):&#160;common.cpp']]],
  ['createcontext',['createContext',['../common_8cpp.html#a6fc67d121370b02ac8bff71ec00a7665',1,'createContext(cl_context *context):&#160;common.cpp'],['../common_8h.html#a6fc67d121370b02ac8bff71ec00a7665',1,'createContext(cl_context *context):&#160;common.cpp']]],
  ['createprogram',['createProgram',['../common_8cpp.html#a4feec45e4b990aad8e40cc3faa32a9c8',1,'createProgram(cl_context context, cl_device_id device, string filename, cl_program *program):&#160;common.cpp'],['../common_8h.html#a7fe72dc9fb4aad614e19d6bfbb2a7fce',1,'createProgram(cl_context context, cl_device_id device, std::string filename, cl_program *program):&#160;common.h']]],
  ['createstartx',['createStartX',['../mandelbrot_8cl.html#a4dffa8ed5ea4612c75f705e514351c4a',1,'mandelbrot.cl']]],
  ['creator1',['creator1',['../structbitmap_header.html#ad1281577a12cb4314cfe869877135231',1,'bitmapHeader']]],
  ['creator2',['creator2',['../structbitmap_header.html#aafdafe00204ad8448ab9cd98aa3040b2',1,'bitmapHeader']]]
];
