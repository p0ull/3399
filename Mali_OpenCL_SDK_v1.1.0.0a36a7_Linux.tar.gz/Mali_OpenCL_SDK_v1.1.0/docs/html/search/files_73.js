var searchData=
[
  ['sgemm_2ecl',['sgemm.cl',['../sgemm_8cl.html',1,'']]],
  ['sgemm_2ecpp',['sgemm.cpp',['../sgemm_8cpp.html',1,'']]],
  ['sgemm_2edox',['sgemm.dox',['../sgemm_8dox.html',1,'']]],
  ['sobel_2ecl',['sobel.cl',['../sobel_8cl.html',1,'']]],
  ['sobel_2ecpp',['sobel.cpp',['../sobel_8cpp.html',1,'']]],
  ['sobel_2edox',['sobel.dox',['../sobel_8dox.html',1,'']]],
  ['sobel_5fno_5fvectors_2ecl',['sobel_no_vectors.cl',['../sobel__no__vectors_8cl.html',1,'']]],
  ['sobel_5fno_5fvectors_2ecpp',['sobel_no_vectors.cpp',['../sobel__no__vectors_8cpp.html',1,'']]],
  ['support_2edox',['support.dox',['../support_8dox.html',1,'']]]
];
