var searchData=
[
  ['rawbitmapsize',['rawBitmapSize',['../structbitmap_information_header.html#abd9001c6c1eefbef9c53f15ec6f3162a',1,'bitmapInformationHeader']]]
];
