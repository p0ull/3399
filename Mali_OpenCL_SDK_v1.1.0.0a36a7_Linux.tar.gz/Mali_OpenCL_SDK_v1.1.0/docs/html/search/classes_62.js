var searchData=
[
  ['bitmapheader',['bitmapHeader',['../structbitmap_header.html',1,'']]],
  ['bitmapinformationheader',['bitmapInformationHeader',['../structbitmap_information_header.html',1,'']]],
  ['bitmapmagic',['bitmapMagic',['../structbitmap_magic.html',1,'']]]
];
