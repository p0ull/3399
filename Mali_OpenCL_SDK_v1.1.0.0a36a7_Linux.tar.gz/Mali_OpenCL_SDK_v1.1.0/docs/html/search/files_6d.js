var searchData=
[
  ['main_5fpage_2edox',['main_page.dox',['../main__page_8dox.html',1,'']]],
  ['mandelbrot_2ecl',['mandelbrot.cl',['../mandelbrot_8cl.html',1,'']]],
  ['mandelbrot_2ecpp',['mandelbrot.cpp',['../mandelbrot_8cpp.html',1,'']]],
  ['mandelbrot_2edox',['mandelbrot.dox',['../mandelbrot_8dox.html',1,'']]],
  ['memory_5fbuffers_2edox',['memory_buffers.dox',['../memory__buffers_8dox.html',1,'']]]
];
