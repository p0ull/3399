var searchData=
[
  ['max_5fiter',['MAX_ITER',['../mandelbrot_8cl.html#acd517c6f195c75b9dd0f3aad65326f3b',1,'mandelbrot.cl']]]
];
