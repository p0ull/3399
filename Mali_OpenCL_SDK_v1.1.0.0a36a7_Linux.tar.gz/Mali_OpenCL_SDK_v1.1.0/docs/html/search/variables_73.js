var searchData=
[
  ['sampler',['sampler',['../image__scaling_8cl.html#a9165c6046146d2d28cc268394d585f17',1,'image_scaling.cl']]],
  ['size',['size',['../structbitmap_information_header.html#afd30cb5246210713920211afb56f13f0',1,'bitmapInformationHeader']]]
];
