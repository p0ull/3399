var searchData=
[
  ['height',['height',['../structbitmap_information_header.html#a5c5209b385872825e8f9c629ac288a12',1,'bitmapInformationHeader']]],
  ['hello_5fworld_2edox',['hello_world.dox',['../hello__world_8dox.html',1,'']]],
  ['hello_5fworld_5fc_2ecpp',['hello_world_c.cpp',['../hello__world__c_8cpp.html',1,'']]],
  ['hello_5fworld_5fopencl',['hello_world_opencl',['../hello__world__opencl_8cl.html#a1e483e8dc82df49f47005c9ede1f0ed7',1,'hello_world_opencl.cl']]],
  ['hello_5fworld_5fopencl_2ecl',['hello_world_opencl.cl',['../hello__world__opencl_8cl.html',1,'']]],
  ['hello_5fworld_5fopencl_2ecpp',['hello_world_opencl.cpp',['../hello__world__opencl_8cpp.html',1,'']]],
  ['hello_5fworld_5fopencl_2edox',['hello_world_opencl.dox',['../hello__world__opencl_8dox.html',1,'']]],
  ['hello_5fworld_5frunning_2edox',['hello_world_running.dox',['../hello__world__running_8dox.html',1,'']]],
  ['hello_5fworld_5fvector',['hello_world_vector',['../hello__world__vector_8cl.html#afbd9d391c741f52cb9cd5a53afd57d89',1,'hello_world_vector.cl']]],
  ['hello_5fworld_5fvector_2ecl',['hello_world_vector.cl',['../hello__world__vector_8cl.html',1,'']]],
  ['hello_5fworld_5fvector_2ecpp',['hello_world_vector.cpp',['../hello__world__vector_8cpp.html',1,'']]],
  ['hello_5fworld_5fvector_2edox',['hello_world_vector.dox',['../hello__world__vector_8dox.html',1,'']]],
  ['hello_20world',['Hello World',['../hello_world_tutorial.html',1,'tutorials']]],
  ['horizontalresolution',['horizontalResolution',['../structbitmap_information_header.html#a39272c25c46f5628cdefc3965f4f6e0d',1,'bitmapInformationHeader']]]
];
