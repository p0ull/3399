var searchData=
[
  ['image_20objects',['Image Objects',['../image_objects_tutorial.html',1,'tutorials']]],
  ['image_20scaling',['Image Scaling',['../image_scaling_tutorial.html',1,'imageObjectsTutorial']]]
];
