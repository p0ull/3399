var searchData=
[
  ['height',['height',['../structbitmap_information_header.html#a5c5209b385872825e8f9c629ac288a12',1,'bitmapInformationHeader']]],
  ['horizontalresolution',['horizontalResolution',['../structbitmap_information_header.html#a39272c25c46f5628cdefc3965f4f6e0d',1,'bitmapInformationHeader']]]
];
