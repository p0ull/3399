var searchData=
[
  ['width',['width',['../structbitmap_information_header.html#abb2a108b489900502eb06b3982b0dc02',1,'bitmapInformationHeader']]]
];
