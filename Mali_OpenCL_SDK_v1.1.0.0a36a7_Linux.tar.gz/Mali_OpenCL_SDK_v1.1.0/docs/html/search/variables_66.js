var searchData=
[
  ['filesize',['fileSize',['../structbitmap_header.html#ad06f4dbac80aa4d85163d3862ed34197',1,'bitmapHeader']]]
];
