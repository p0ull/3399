var searchData=
[
  ['mandelbrot',['Mandelbrot',['../mandelbrot_tutorial.html',1,'tutorials']]],
  ['memory_20buffers',['Memory Buffers',['../memory_buffers_tutorial.html',1,'tutorials']]]
];
