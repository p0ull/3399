var searchData=
[
  ['quick_20start_20guide',['Quick Start Guide',['../quick_start.html',1,'']]]
];
