var searchData=
[
  ['printprofilinginfo',['printProfilingInfo',['../common_8cpp.html#a33ff0013574626bb47147495e02b5d08',1,'printProfilingInfo(cl_event event):&#160;common.cpp'],['../common_8h.html#a33ff0013574626bb47147495e02b5d08',1,'printProfilingInfo(cl_event event):&#160;common.cpp']]],
  ['printsupported2dimageformats',['printSupported2DImageFormats',['../common_8cpp.html#a736045ae74d9ed8d35cacce59b92772a',1,'printSupported2DImageFormats(cl_context context):&#160;common.cpp'],['../common_8h.html#a736045ae74d9ed8d35cacce59b92772a',1,'printSupported2DImageFormats(cl_context context):&#160;common.cpp']]]
];
