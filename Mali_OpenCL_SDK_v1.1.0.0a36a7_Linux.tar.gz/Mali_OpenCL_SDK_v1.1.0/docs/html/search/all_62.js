var searchData=
[
  ['bitmapheader',['bitmapHeader',['../structbitmap_header.html',1,'']]],
  ['bitmapinformationheader',['bitmapInformationHeader',['../structbitmap_information_header.html',1,'']]],
  ['bitmapmagic',['bitmapMagic',['../structbitmap_magic.html',1,'']]],
  ['bitsperpixel',['bitsPerPixel',['../structbitmap_information_header.html#ae25aec64837eed48f745ae7728af7dff',1,'bitmapInformationHeader']]]
];
