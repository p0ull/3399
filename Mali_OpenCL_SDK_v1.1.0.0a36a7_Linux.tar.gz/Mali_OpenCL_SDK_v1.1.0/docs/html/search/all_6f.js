var searchData=
[
  ['offset',['offset',['../structbitmap_header.html#a5e74a0bfe6340ad581369b48bce59dbe',1,'bitmapHeader']]]
];
