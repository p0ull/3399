var searchData=
[
  ['savetobitmap',['saveToBitmap',['../image_8cpp.html#ad7fed8ed5795a8ddd3e86265cc5a4d31',1,'saveToBitmap(string filename, int width, int height, const unsigned char *imageData):&#160;image.cpp'],['../image_8h.html#ab9744225ef92254ada77ddaeaddad25d',1,'saveToBitmap(std::string filename, int width, int height, const unsigned char *imageData):&#160;image.h']]],
  ['sgemm',['sgemm',['../sgemm_8cl.html#abfe7be25d42e6bb53f76001bdbab6b25',1,'sgemm.cl']]],
  ['sgemminitialize',['sgemmInitialize',['../sgemm_8cpp.html#ad08e4e7aca2ad6900f5f5c84d88b6aff',1,'sgemm.cpp']]],
  ['sobel',['sobel',['../sobel_8cl.html#ad999d1681236d38b8c3e05c610a99850',1,'sobel.cl']]],
  ['sobel_5fno_5fvectors',['sobel_no_vectors',['../sobel__no__vectors_8cl.html#aba83b870a7ef709e9a5608496084ec3a',1,'sobel_no_vectors.cl']]]
];
