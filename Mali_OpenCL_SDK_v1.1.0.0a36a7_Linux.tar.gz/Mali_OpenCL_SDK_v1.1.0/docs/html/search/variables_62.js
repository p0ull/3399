var searchData=
[
  ['bitsperpixel',['bitsPerPixel',['../structbitmap_information_header.html#ae25aec64837eed48f745ae7728af7dff',1,'bitmapInformationHeader']]]
];
