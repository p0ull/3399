var searchData=
[
  ['hello_5fworld_5fopencl',['hello_world_opencl',['../hello__world__opencl_8cl.html#a1e483e8dc82df49f47005c9ede1f0ed7',1,'hello_world_opencl.cl']]],
  ['hello_5fworld_5fvector',['hello_world_vector',['../hello__world__vector_8cl.html#afbd9d391c741f52cb9cd5a53afd57d89',1,'hello_world_vector.cl']]]
];
