var searchData=
[
  ['template',['template',['../template_8cl.html#a3fd9dfc155a2b110d8632041d0961625',1,'template.cl']]]
];
