var searchData=
[
  ['verticalresolution',['verticalResolution',['../structbitmap_information_header.html#a9596ce6332941aafbbf85b7e379e948f',1,'bitmapInformationHeader']]]
];
