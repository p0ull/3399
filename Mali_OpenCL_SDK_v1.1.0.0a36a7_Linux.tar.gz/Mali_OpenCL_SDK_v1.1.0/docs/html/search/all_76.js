var searchData=
[
  ['vectorizing_20your_20opencl_20code',['Vectorizing your OpenCL code',['../hello_world_vector_tutorial.html',1,'helloWorldTutorial']]],
  ['verticalresolution',['verticalResolution',['../structbitmap_information_header.html#a9596ce6332941aafbbf85b7e379e948f',1,'bitmapInformationHeader']]]
];
