var searchData=
[
  ['sgemm',['SGEMM',['../sgemm_tutorial.html',1,'tutorials']]],
  ['sobel_20filter',['Sobel Filter',['../sobel_tutorial.html',1,'tutorials']]],
  ['support',['Support',['../support.html',1,'']]]
];
