var searchData=
[
  ['running_20the_20samples',['Running the Samples',['../hello_world_running_tutorial.html',1,'helloWorldTutorial']]],
  ['rawbitmapsize',['rawBitmapSize',['../structbitmap_information_header.html#abd9001c6c1eefbef9c53f15ec6f3162a',1,'bitmapInformationHeader']]],
  ['rgbatorgb',['RGBAToRGB',['../image_8cpp.html#a872cec0732df69b80796a61acea716f0',1,'RGBAToRGB(const unsigned char *const rgbaData, unsigned char *const rgbData, int width, int height):&#160;image.cpp'],['../image_8h.html#a3d566da55411efac7e49e2f33bf6c155',1,'RGBAToRGB(const unsigned char *rgbaData, unsigned char *rgbData, int width, int height):&#160;image.cpp']]],
  ['rgbtoluminance',['RGBToLuminance',['../image_8cpp.html#a75fa143dccc45f3d5dc030884ca09cc9',1,'RGBToLuminance(const unsigned char *const rgbData, unsigned char *const luminanceData, int width, int height):&#160;image.cpp'],['../image_8h.html#a95b53cb5341aa2660b74a5f3a40228de',1,'RGBToLuminance(const unsigned char *rgbData, unsigned char *luminanceData, int width, int height):&#160;image.cpp']]],
  ['rgbtorgba',['RGBToRGBA',['../image_8cpp.html#a83b7aea3d44c26db2222227c0dc5d19a',1,'RGBToRGBA(const unsigned char *const rgbData, unsigned char *const rgbaData, int width, int height):&#160;image.cpp'],['../image_8h.html#a189e940abcfb40459918c86ab01a1121',1,'RGBToRGBA(const unsigned char *rgbData, unsigned char *rgbaData, int width, int height):&#160;image.cpp']]]
];
