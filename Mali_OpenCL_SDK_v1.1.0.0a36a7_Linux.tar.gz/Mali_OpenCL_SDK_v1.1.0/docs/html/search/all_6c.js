var searchData=
[
  ['loadfrombitmap',['loadFromBitmap',['../image_8cpp.html#a24ebc43a2f3d72aff84912a1a69f2c39',1,'loadFromBitmap(const string filename, int *const width, int *const height, unsigned char **imageData):&#160;image.cpp'],['../image_8h.html#ae8afb226cfa212cce225a77a0ff79121',1,'loadFromBitmap(std::string filename, int *width, int *height, unsigned char **imageData):&#160;image.h']]],
  ['long_5fvectors',['long_vectors',['../64__bit__integer_8cl.html#a6bcf29a04ecbeff8aa2ed8fe75539098',1,'64_bit_integer.cl']]],
  ['luminancetorgb',['luminanceToRGB',['../image_8cpp.html#a9390e4ddc634d83452a15e93017ab979',1,'luminanceToRGB(const unsigned char *luminanceData, unsigned char *rgbData, int width, int height):&#160;image.cpp'],['../image_8h.html#a9390e4ddc634d83452a15e93017ab979',1,'luminanceToRGB(const unsigned char *luminanceData, unsigned char *rgbData, int width, int height):&#160;image.cpp']]]
];
