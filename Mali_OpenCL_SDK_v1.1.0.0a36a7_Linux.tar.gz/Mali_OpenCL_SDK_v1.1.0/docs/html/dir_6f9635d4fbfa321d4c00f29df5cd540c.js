var dir_6f9635d4fbfa321d4c00f29df5cd540c =
[
    [ "64_bit_integer", "dir_98aa652b5938058672ba296b58b44cbf.html", "dir_98aa652b5938058672ba296b58b44cbf" ],
    [ "fir_float", "dir_cbd57f3d7d7e9034c814d8124b45dbb2.html", "dir_cbd57f3d7d7e9034c814d8124b45dbb2" ],
    [ "hello_world_c", "dir_e76a63218516693600e6e995cc89a2c4.html", "dir_e76a63218516693600e6e995cc89a2c4" ],
    [ "hello_world_opencl", "dir_75d5c689b70aefa142bdf5ebcb7d98a3.html", "dir_75d5c689b70aefa142bdf5ebcb7d98a3" ],
    [ "hello_world_vector", "dir_0289395444cf489a29bc36f15be66f35.html", "dir_0289395444cf489a29bc36f15be66f35" ],
    [ "image_scaling", "dir_10f12679427188891e820fce3e11401a.html", "dir_10f12679427188891e820fce3e11401a" ],
    [ "mandelbrot", "dir_490217e45394b06d48a471b031b70a3e.html", "dir_490217e45394b06d48a471b031b70a3e" ],
    [ "sgemm", "dir_df019e407d3fcaab5e49d9c13350c94c.html", "dir_df019e407d3fcaab5e49d9c13350c94c" ],
    [ "sobel", "dir_dd0c2a8767cfede8cdb873abaafa716f.html", "dir_dd0c2a8767cfede8cdb873abaafa716f" ],
    [ "sobel_no_vectors", "dir_33f3275c1127fb7d435e719a53b54021.html", "dir_33f3275c1127fb7d435e719a53b54021" ],
    [ "template", "dir_8c530a8c9903b6ceb2227ad2f52f6cd5.html", "dir_8c530a8c9903b6ceb2227ad2f52f6cd5" ]
];