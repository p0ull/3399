var sobel__no__vectors_8cl =
[
    [ "sobel_no_vectors", "sobel__no__vectors_8cl.html#aba83b870a7ef709e9a5608496084ec3a", null ]
];