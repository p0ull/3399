var structbitmap_information_header =
[
    [ "bitsPerPixel", "structbitmap_information_header.html#ae25aec64837eed48f745ae7728af7dff", null ],
    [ "compressionType", "structbitmap_information_header.html#a1a6659ee7987cc1be662ec93a6f2eef7", null ],
    [ "height", "structbitmap_information_header.html#a5c5209b385872825e8f9c629ac288a12", null ],
    [ "horizontalResolution", "structbitmap_information_header.html#a39272c25c46f5628cdefc3965f4f6e0d", null ],
    [ "numberOfColorPlanes", "structbitmap_information_header.html#a92ce2fb0499b65ccb0dccbec12b44c4c", null ],
    [ "numberOfColors", "structbitmap_information_header.html#ab8a3e77e6b66d1361d65523a99104f5f", null ],
    [ "numberOfImportantColors", "structbitmap_information_header.html#aa6296b037bae6831a6c53f6115c29769", null ],
    [ "rawBitmapSize", "structbitmap_information_header.html#abd9001c6c1eefbef9c53f15ec6f3162a", null ],
    [ "size", "structbitmap_information_header.html#afd30cb5246210713920211afb56f13f0", null ],
    [ "verticalResolution", "structbitmap_information_header.html#a9596ce6332941aafbbf85b7e379e948f", null ],
    [ "width", "structbitmap_information_header.html#abb2a108b489900502eb06b3982b0dc02", null ]
];