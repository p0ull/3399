var dir_53e809feb72b43d0f52f5efc50237d2d =
[
    [ "sobel_no_vectors.cl", "sobel__no__vectors_8cl.html", "sobel__no__vectors_8cl" ]
];