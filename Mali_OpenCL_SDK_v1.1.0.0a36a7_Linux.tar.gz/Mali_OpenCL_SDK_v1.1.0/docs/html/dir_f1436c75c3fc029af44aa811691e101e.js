var dir_f1436c75c3fc029af44aa811691e101e =
[
    [ "mandelbrot.cl", "mandelbrot_8cl.html", "mandelbrot_8cl" ]
];