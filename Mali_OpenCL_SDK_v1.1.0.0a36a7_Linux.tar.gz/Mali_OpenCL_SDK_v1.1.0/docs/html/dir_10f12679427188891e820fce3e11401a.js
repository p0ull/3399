var dir_10f12679427188891e820fce3e11401a =
[
    [ "assets", "dir_0dae9d24a39dcc22094c5116ff3a8be1.html", "dir_0dae9d24a39dcc22094c5116ff3a8be1" ],
    [ "image_scaling.cpp", "image__scaling_8cpp.html", "image__scaling_8cpp" ]
];