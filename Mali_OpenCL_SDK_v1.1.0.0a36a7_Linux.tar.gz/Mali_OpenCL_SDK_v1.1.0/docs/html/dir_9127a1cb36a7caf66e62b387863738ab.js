var dir_9127a1cb36a7caf66e62b387863738ab =
[
    [ "hello_world_opencl.cl", "hello__world__opencl_8cl.html", "hello__world__opencl_8cl" ]
];