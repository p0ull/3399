var hello__world__opencl_8cl =
[
    [ "hello_world_opencl", "hello__world__opencl_8cl.html#a1e483e8dc82df49f47005c9ede1f0ed7", null ]
];