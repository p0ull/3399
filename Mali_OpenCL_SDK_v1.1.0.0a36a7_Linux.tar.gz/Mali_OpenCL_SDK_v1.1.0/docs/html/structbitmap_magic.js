var structbitmap_magic =
[
    [ "magic", "structbitmap_magic.html#a477646205ecad5019613626f0b478694", null ]
];