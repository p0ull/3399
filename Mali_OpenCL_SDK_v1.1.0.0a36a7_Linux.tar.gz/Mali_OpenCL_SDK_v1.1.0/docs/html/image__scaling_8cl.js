var image__scaling_8cl =
[
    [ "image_scaling", "image__scaling_8cl.html#a2f2c7656161bcd4a3956c362d0052b26", null ],
    [ "sampler", "image__scaling_8cl.html#a9165c6046146d2d28cc268394d585f17", null ]
];