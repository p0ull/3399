var dir_33f3275c1127fb7d435e719a53b54021 =
[
    [ "assets", "dir_53e809feb72b43d0f52f5efc50237d2d.html", "dir_53e809feb72b43d0f52f5efc50237d2d" ],
    [ "sobel_no_vectors.cpp", "sobel__no__vectors_8cpp.html", "sobel__no__vectors_8cpp" ]
];